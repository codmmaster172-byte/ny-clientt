package dev.nyx.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class KillAura {
    public boolean enabled = false;
    private EntityPlayer target;
    private long nextAttack = 0;
    private boolean resprint = false, blocking = false;
    private double dx, dy, dz;
    private int driftTicks = 0;

    private void block(Minecraft mc, EntityPlayerSP p) {
        ItemStack h = p.getHeldItem();
        if (h == null || mc.getNetHandler() == null) return;
        mc.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(h));
        blocking = true;
    }

    private void unblock(Minecraft mc) {
        if (!blocking) return;
        blocking = false;
        if (mc.getNetHandler() == null) return;
        mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(
            C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
    }

    public void tick(Minecraft mc, boolean paused) {
        EntityPlayerSP p = mc.thePlayer;

        // sprint reset: attacking drops sprint client-side, so restore it if W is still held
        if (resprint) {
            resprint = false;
            if (Settings.bool("ka.sprintReset") && mc.gameSettings.keyBindForward.isKeyDown()
                    && !p.isCollidedHorizontally && p.getFoodStats().getFoodLevel() > 6
                    && !p.isSneaking() && !p.isUsingItem()) {
                p.setSprinting(true);
            }
        }

        if (!enabled || paused || mc.currentScreen != null) { unblock(mc); target = null; return; }
        if (p.isUsingItem()) { target = null; return; }

        Vec3 eye = p.getPositionEyes(1.0F);
        double range = Settings.num("ka.range");
        float fov = (float) Settings.num("ka.fov");
        String sort = Settings.str("ka.sort");
        boolean sticky = Settings.bool("ka.sticky");

        EntityPlayer best = null;
        double bestScore = Double.MAX_VALUE;
        for (EntityPlayer e : mc.theWorld.playerEntities) {
            if (!Targets.isValid(mc, p, e)) continue;
            Vec3 pt = Rot.closest(e.getEntityBoundingBox(), eye);
            double d = pt.distanceTo(eye);
            if (d > range) continue;
            float[] r = Rot.to(eye, pt);
            float angle = Math.abs(Rot.wrap(r[0] - p.rotationYaw));
            if (angle > fov / 2F) continue;
            if (!Settings.bool("ka.throughWalls") && !p.canEntityBeSeen(e)) continue;
            double score = sort.equals("health") ? e.getHealth() : sort.equals("angle") ? angle : d;
            if (sticky && e == target) score -= 1000.0;
            if (score < bestScore) { bestScore = score; best = e; }
        }
        if (best == null) { unblock(mc); target = null; return; }
        target = best;

        boolean sword = p.getHeldItem() != null && p.getHeldItem().getItem() instanceof ItemSword;
        boolean wantBlock = Settings.str("ka.autoblock").equals("packet") && sword;
        if (!wantBlock) unblock(mc);

        // 1) attack using the rotation the server already has (what was sent last tick)
        float[] base = RotationManager.cur(p);
        AxisAlignedBB bb = target.getEntityBoundingBox();
        float b = target.getCollisionBorderSize();
        Vec3 look = Rot.look(base[0], base[1]);
        Vec3 end = eye.addVector(look.xCoord * range, look.yCoord * range, look.zCoord * range);
        boolean aimed = !Settings.bool("ka.rayCast") || bb.expand(b, b, b).calculateIntercept(eye, end) != null;
        boolean hurtOk = target.hurtTime <= (int) Settings.num("ka.hurtTime");
        long now = System.currentTimeMillis();

        if (aimed && hurtOk && now >= nextAttack) {
            if (blocking) unblock(mc);
            boolean was = p.isSprinting();
            p.swingItem();
            mc.playerController.attackEntity(p, target);
            if (was) resprint = true;
            double lo = Math.min(Settings.num("ka.cpsMin"), Settings.num("ka.cpsMax"));
            double hi = Math.max(Settings.num("ka.cpsMin"), Settings.num("ka.cpsMax"));
            double cps = lo + Rot.R.nextDouble() * (hi - lo);
            nextAttack = now + (long) (1000.0 / Math.max(1.0, cps) * (0.9 + Rot.R.nextDouble() * 0.2));
        }
        if (wantBlock && !blocking) block(mc, p);

        // 2) pick the rotation for the next packet
        if (--driftTicks <= 0) {
            driftTicks = 8 + Rot.R.nextInt(8);
            dx = (Rot.R.nextDouble() - 0.5) * 0.2;
            dy = (Rot.R.nextDouble() - 0.5) * 0.3;
            dz = (Rot.R.nextDouble() - 0.5) * 0.2;
        }
        Vec3 c = Rot.closest(bb.expand(-0.08, -0.15, -0.08), eye);
        Vec3 aim = Rot.closest(bb, new Vec3(c.xCoord + dx, c.yCoord + dy, c.zCoord + dz));
        float[] want = Rot.to(eye, aim);
        float lo = (float) Math.min(Settings.num("ka.turnMin"), Settings.num("ka.turnMax"));
        float hi = (float) Math.max(Settings.num("ka.turnMin"), Settings.num("ka.turnMax"));
        float step = lo + Rot.R.nextFloat() * (hi - lo);

        if (Settings.bool("ka.silent")) {
            RotationManager.request(p, want[0], want[1], step);
        } else {
            float[] n = Rot.smooth(p.rotationYaw, p.rotationPitch, want[0], want[1], step);
            p.rotationYaw = n[0];
            p.rotationPitch = MathHelper.clamp_float(n[1], -90F, 90F);
        }
    }
}
