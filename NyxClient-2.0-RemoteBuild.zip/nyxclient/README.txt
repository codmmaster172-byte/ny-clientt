NyxClient 2.0 - Forge 1.8.9 (11.15.1.2318), client-only
Build: JDK 8, ForgeGradle 2.1 -> ./gradlew setupDecompWorkspace build -> build/libs/nyxclient-2.0.jar
Android (Zalith Launcher 2): install 1.8.9 + Forge 11.15.1.2318, put the jar in .minecraft/mods.
Keys: R = KillAura, G = Scaffold.
Commands: /nyx list [prefix] | get k | set k v | ka | scaffold | save
Config: .minecraft/config/nyxclient.properties
