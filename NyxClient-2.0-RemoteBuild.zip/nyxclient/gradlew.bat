@echo off
setlocal EnableExtensions
title NyxClient 2.0 Auto Build
cd /d "%~dp0"

echo ==========================================
echo        NyxClient 2.0 Auto Builder
echo ==========================================
echo.

if not exist "build.gradle" (
  echo ERROR: build.gradle not found.
  echo Extract this ZIP, then run gradlew.bat from the nyxclient folder.
  pause
  exit /b 1
)

REM Legacy ForgeGradle 2.1 is intended for Java 8. Prefer JAVA_HOME if set.
if defined JAVA_HOME (
  if exist "%JAVA_HOME%\bin\java.exe" set "PATH=%JAVA_HOME%\bin;%PATH%"
)
where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java was not found.
  echo Install a JDK 8 and set JAVA_HOME to its folder, then retry.
  pause
  exit /b 1
)

echo Detected Java:
java -version
echo.
echo NOTE: This Minecraft 1.8.9 / ForgeGradle 2.1 project normally needs Java 8.
echo Java 17/21/25 may fail with this legacy build.
echo.

set "GRADLE_VERSION=2.14.1"
set "TOOLS_DIR=%~dp0.tools"
set "GRADLE_HOME_LOCAL=%TOOLS_DIR%\gradle-%GRADLE_VERSION%"
set "GRADLE_ZIP=%TOOLS_DIR%\gradle-%GRADLE_VERSION%-bin.zip"
set "GRADLE_EXE=%GRADLE_HOME_LOCAL%\bin\gradle.bat"

if exist "%GRADLE_EXE%" goto :build

echo Gradle %GRADLE_VERSION% is not bundled. Trying to download it automatically...
if not exist "%TOOLS_DIR%" mkdir "%TOOLS_DIR%"

powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_ZIP%' -UseBasicParsing; exit 0 } catch { Write-Host $_; exit 1 }"
if errorlevel 1 (
  echo.
  echo ERROR: Could not download Gradle. Check your internet connection or network restrictions.
  echo Download manually: https://services.gradle.org/distributions/gradle-2.14.1-bin.zip
  echo Extract it so this file exists:
  echo %GRADLE_EXE%
  pause
  exit /b 1
)

echo Extracting Gradle...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Expand-Archive -LiteralPath '%GRADLE_ZIP%' -DestinationPath '%TOOLS_DIR%' -Force; exit 0 } catch { Write-Host $_; exit 1 }"
if errorlevel 1 (
  echo ERROR: Could not extract Gradle.
  pause
  exit /b 1
)

if not exist "%GRADLE_EXE%" (
  echo ERROR: Gradle executable was not found after extraction.
  pause
  exit /b 1
)

:build
echo.
echo Running ForgeGradle setup. The first build downloads Minecraft/Forge dependencies.
call "%GRADLE_EXE%" --no-daemon setupDecompWorkspace
if errorlevel 1 goto :failed

echo.
echo Compiling and packaging NyxClient...
call "%GRADLE_EXE%" --no-daemon build
if errorlevel 1 goto :failed

echo.
echo ==========================================
echo BUILD COMPLETED
echo Look in: %~dp0build\libs
echo ==========================================
dir /b "%~dp0build\libs\*.jar" 2>nul
pause
exit /b 0

:failed
echo.
echo BUILD FAILED. Read the error above.
echo Common causes: Java version incompatibility or blocked Forge/Maven downloads.
echo The output JAR is only valid if Gradle reports BUILD SUCCESSFUL.
pause
exit /b 1
